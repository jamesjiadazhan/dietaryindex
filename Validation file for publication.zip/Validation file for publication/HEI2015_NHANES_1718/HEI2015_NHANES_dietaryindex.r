library(dplyr)
library(haven)
library(readr)
# Loading dependency packages first can help avoid the namespace conflict if you want to use dplyr by yourself later in addition to the internal use of dplyr within the diataryindex package
# Load the dietaryindex package
library(dietaryindex)

data("NHANES_20172018")

head(NHANES_20172018)

setwd("/Users/yan/Desktop/Emory University - Ph.D./dietaryindex_package/Validation file for publication/HEI2015_NHANES_1718")
## HEI2015_NHANES_FPED validation using the SAS codes from National Cancer Institute (https://epi.grants.cancer.gov/hei/sas-code.html)
# day 1 only
HEI2015_NHANES_FPED_1718 = HEI2015_NHANES_FPED(
    FPED_PATH = NHANES_20172018$FPED,
    NUTRIENT_PATH = NHANES_20172018$NUTRIENT,
    DEMO_PATH = NHANES_20172018$DEMO
)

# save the result
write_csv(HEI2015_NHANES_FPED_1718, "dietaryindex_HEI2015_1718.csv")

# read in the SAS result using the NCI SAS codes
HEI2015_NHANES_SAS_1718 = read_csv("SAS_HEI2015_1718.csv")

# check if the HEI2015_TOTAL_SCORE in the SAS results are the same as the HEI2015_ALL in the R results in two decimals
HEI2015_NHANES_FPED_1718$HEI2015_ALL = round(HEI2015_NHANES_FPED_1718$HEI2015_ALL, 2)
HEI2015_NHANES_SAS_1718$HEI2015_TOTAL_SCORE = round(HEI2015_NHANES_SAS_1718$HEI2015_TOTAL_SCORE, 2)

table(HEI2015_NHANES_FPED_1718$HEI2015_ALL == HEI2015_NHANES_SAS_1718$HEI2015_TOTAL_SCORE)
## all results are TRUE, which means the R result is the same as the SAS result


